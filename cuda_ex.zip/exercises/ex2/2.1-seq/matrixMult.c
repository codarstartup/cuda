#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

void matrixMult(float *A, float *B, float *C, int N){
	int i, j, k;
	for(i = 0; i < N; i++)
		for(j = 0; j < N; j++)
			for(k = 0; k < N; k++)
				C[i * N + j] += A[i * N + k] * B[k * N + j];
}

int main(int argc, char **argv){
	if(argc != 2){
		fprintf(stderr, "Usage: %s <number_of_elements>\n", argv[0]);
		exit(1);
	}
	int ok = 1;
	int i, j, N = atoi(argv[1]);
	float *A, *B, *C;
	A = (float *) malloc(N * N * sizeof(float));
	B = (float *) malloc(N * N * sizeof(float));
	C = (float *) malloc(N * N * sizeof(float));
	
	printf("matrix size = %dx%d\n", N, N);
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			A[i * N + j] = 1;
			B[i * N + j] = 1;
			C[i * N + j] = 0;
		}
	}

	printf("running with %d thread\n", omp_get_num_threads());

	double start = omp_get_wtime();
	matrixMult(A, B, C, N);
	double end   = omp_get_wtime();
	
	for(i = 0; i < N; i++)
		for(j = 0; j < N; j++)
			if(C[i * N + j] != (float) N){
				printf("first error on position [%d,%d]\n", i, j);
				ok = 0;				
				i = N;
				j = N;
			}

	printf("result is %s\n", ok == 1 ? "ok" : "wrong");
	printf("matrixMult execution time %.5lf\n", end - start);
	free(A);
	free(B);
	free(C);

	return 0;
}
