#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void stencil(double *A, double *Aold, int N){
	int i, j;
	for(i = 1; i < N - 1; i++)
		for(j = 1; j < N - 1; j++)
			A[i * N + j] = 0.25 * (Aold[(i - 1) * N + j] + Aold[i * N + j - 1] + Aold[i * N + j + 1] + Aold[(i + 1) * N + j]);
}

int main(int argc, char **argv){
	if(argc != 2){
		fprintf(stderr, "Usage: %s <number_of_elements>\n", argv[0]);
		exit(1);
	}
	int i, N = atoi(argv[1]);
	double *A, *Aold;
	A    = (double *) malloc(N * N * sizeof(double));
	Aold = (double *) malloc(N * N * sizeof(double));
	
	printf("matrix size = %dx%d\n", N, N);
	for(i = 0; i < N * N; i++){
		A[i]    = 0;
		Aold[i] = 0;
	}
	for(i = 0; i < N; i++){
		A[i * N]    = 1.0;
		Aold[i * N] = 1.0;
	}	

	printf("running with %d thread\n", omp_get_num_threads());

	double start = omp_get_wtime();
	for(i = 0; i < 1000; i++){
		stencil(A, Aold, N);
		
		double* tmp = A;
		A = Aold;
		Aold = tmp;
	}
	double end   = omp_get_wtime();
	
	double check = 0;
	for(i = 0; i < N * N; i++)
		check += A[i];
	printf("\nchecksum %.5lf\n\n", check);
	
	printf("Jacobi execution time %.5lf\n", end - start);
	free(A);
	free(Aold);

	return 0;
}