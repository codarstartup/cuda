#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <omp.h>

void vecAdd(int *A, int *B, int *C, int N){
	int i;
	for(i = 0; i < N; i++)
		C[i] = A[i] + B[i];
}

int main(int argc, char **argv){
	if(argc != 2){
		fprintf(stderr, "Usage: %s <number_of_elements>\n", argv[0]);
		exit(1);
	}
	int ok = 1;
	long long int i, N = atoll(argv[1]) > INT_MAX ? INT_MAX : atoll(argv[1]);
	int *A, *B, *C;
	A = (int *) malloc(N * sizeof(int));
	B = (int *) malloc(N * sizeof(int));
	C = (int *) malloc(N * sizeof(int));
	
	printf("vector size = %lld\n", N);
	for(i = 0; i < N; i++){
		A[i] = i % INT_MAX;
		B[i] = INT_MAX - i % INT_MAX;
		C[i] = 0;
	}

	printf("running with %d thread\n", omp_get_num_threads());

	double start = omp_get_wtime();
	vecAdd(A, B, C, N);
	double end   = omp_get_wtime();

	for(i = 0; i < N; i++)
		if(C[i] != INT_MAX){
			printf("first error on position %lld, %d+%d=%d\n", i, A[i], B[i], C[i]);
			ok = 0;
			break;
		}

	printf("result is %s\n", ok == 1 ? "ok" : "wrong");
	printf("vecAdd execution time %.5lf\n", end - start);
	free(A);
	free(B);
	free(C);

	return 0;
}
